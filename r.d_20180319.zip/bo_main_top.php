<html>
<body>
<a href="logout.php">Logout</a>
</body>
</html>