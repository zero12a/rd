<?php
header("Content-Type: text/html; charset=UTF-8");
header("Cache-Control:no-cache");
header("Pragma:no-cache");

session_start();

require_once("../c.g/include/incDB.php");
require_once("../c.g/include/incSEC.php");
require_once("../c.g/include/incUtil.php");
require_once("../c.g/include/incUser.php");
require_once("../c.g/incConfig.php");

//redis에 넣기
require_once('Predis/Autoloader.php');
Predis\Autoloader::register();
$redis = new Predis\Client('tcp://192.168.210.1:1234');

//외부 파라미터 받기
$REQ["F_EMAIL"] = $_POST["F_EMAIL"];
$REQ["F_PASSWD"] = $_POST["F_PASSWD"];


alog("REQ.F_EMAIL = ". $REQ["F_EMAIL"]);
alog("REQ.F_PASSWD = ". $REQ["F_PASSWD"]);

if($REQ["F_EMAIL"] == ""){JsonMsg("500","100","F_EMAIL 입력해 주세요.");}
if($REQ["F_PASSWD"] == ""){JsonMsg("500","200","F_PASSWD 입력해 주세요.");}

$REQ["F_PASSWD_HASH"] = pwd_hash($REQ["F_PASSWD"],$CFG_SEC_SALT);

alog("REQ.F_PASSWD_HASH = ". $REQ["F_PASSWD_HASH"]);

//DB연결 정보 생성
$db = db_obj_open(getDbSvrInfo("DATING"));

$coltype = "ss";
$sql = "
    SELECT USR_SEQ, USR_ID, USR_NM, USR_PWD 
    FROM CMN_USR 
    WHERE USE_YN = 'Y' and USR_ID = #{F_EMAIL} and USR_PWD = #{F_PASSWD_HASH} 
";

$stmt = makeStmt($db,$sql,$coltype,$REQ);

if(!$stmt)JsonMsg("500","300","SQL makeStmt 실패 했습니다.");

if(!$stmt->execute())JsonMsg("500","100","stmt 실행 실패" . $db->errno . " -> " . $db->error);

$result = $stmt->get_result();
if($row = $result->fetch_array(MYSQLI_NUM))
{
    //log("0 : " . $row[0]);
    //alog("1 : " . $row[1]);
    //alog("2 : " . $row[2]);
    //echo "<br>USR_SEQ : " . $row["USR_SEQ"];

    //사용자정보 세팅
    $REQ["USR_SEQ"] = $row[0];
    $REQ["SUCCESS_YN"] = "Y";
    $REQ["USR_ID"] = $REQ["F_EMAIL"];

    //권한정보 받아오기
    $arrAuth = getUserAuthArray();
    //var_dump($arrAuth);
    setUserAuth($arrAuth);

    //로그정보
    $REQ["AUTH_JSON"] = json_encode($arrAuth);
    saveLoginLog($REQ);

    //세션부여
    setUserSeq($row[0]);
    setUserId($row[1]);    
    
    //RESPONSE 하기
    JsonMsg("200","100","로그인에 성공했습니다.");

}else{

    //로그정보
    $REQ["SUCCESS_YN"] = "N";
    $REQ["USR_SEQ"] = 0;
    $REQ["USR_ID"] = $REQ["F_EMAIL"];
    saveLoginLog($REQ);

    JsonMsg("200","210","이메일 혹은 비밀번호가 일치하지 않습니다.");    
}

//db닫기
$db->close();


function getUserAuthArray(){
    global $db,$REQ;

    $coltype = "i";
    $sql = "
        select b.PGMID, b.AUTH_ID
        from CMN_GRP_USR a
            join CMN_GRP_AUTH b on a.GRP_SEQ = b.GRP_SEQ
        where a.USR_SEQ = #{USR_SEQ} 
        order by b.PGMID, b.AUTH_ID
    ";
    
    $stmt = makeStmt($db,$sql,$coltype,$REQ);
    
    if(!$stmt)JsonMsg("500","300","SQL makeStmt 실패 했습니다.");
    
    if(!$stmt->execute())JsonMsg("500","100","stmt 실행 실패" . $db->errno . " -> " . $db->error);
    

    $tArr =  getStmtArray($stmt);
    $stmt->close();

    $lastPgmid = "";
    $rtnVal = null;
    for($i=0;$i<count($tArr);$i++){
        $tMap = $tArr[$i];
        if($lastPgmid != $tMap["PGMID"]){
            $rtnVal[$tMap["PGMID"]] = array();
            $j=0;          
        }else{
            $j++;        
        }
        $rtnVal[$tMap["PGMID"]][$j] = $tMap["AUTH_ID"];
        $lastPgmid = $tMap["PGMID"];
    }
    
    return $rtnVal;
}

function saveLoginLog($REQ){
    global $db, $_SERVER;

    $REQ["SERVER_NAME"] = $_SERVER["SERVER_NAME"]; 
    $REQ["REMOTE_ADDR"] = $_SERVER["REMOTE_ADDR"]; 
    $REQ["USER_AGENT"] = $_SERVER["HTTP_USER_AGENT"]; 
    $REQ["SESSION_ID"] = session_id(); 

    $coltype = "sssis sss";
    $sql = "
        insert into CMN_LOG_LOGIN ( 
            USR_ID, SESSION_ID, SUCCESS_YN, USR_SEQ, SERVER_NAME
            , REMOTE_ADDR, USER_AGENT, AUTH_JSON
            , ADD_DT
        ) values (
            #{USR_ID}, #{SESSION_ID}, #{SUCCESS_YN}, #{USR_SEQ}, #{SERVER_NAME}
            , #{REMOTE_ADDR}, #{USER_AGENT}, #{AUTH_JSON}
            , date_format(sysdate(),'%Y%m%d%H%i%s')
        ) 
    ";
    
    $stmt = makeStmt($db,$sql,$coltype,$REQ);
    
    if(!$stmt)JsonMsg("500","300","SQL makeStmt 생성 실패 했습니다.");
    
    if(!$stmt->execute())JsonMsg("500","100","stmt 실행 실패 " .  $stmt->error);
    
    return  $db->insert_id;
}
?>